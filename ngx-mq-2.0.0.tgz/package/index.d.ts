import { Signal, InjectionToken, Provider } from '@angular/core';

type MqRetainToken = symbol;
interface MqRetainRef {
    signal: Signal<boolean>;
    token: MqRetainToken;
}

declare function release(query: string, token: MqRetainToken): boolean;

declare function retainUntilDestroy(query: string): MqRetainRef;

type MqBreakpoints = Record<string, number>;
interface CreateMediaQueryOptions {
    /**
     * A debug name for the signal. Used in Angular DevTools to identify the signal.
     */
    debugName?: string;
}

declare function up(bp: string, options?: CreateMediaQueryOptions): Signal<boolean>;
declare function down(bp: string, options?: CreateMediaQueryOptions): Signal<boolean>;
declare function between(minBp: string, maxBp: string, options?: CreateMediaQueryOptions): Signal<boolean>;
declare function matchMediaSignal(query: string, options?: CreateMediaQueryOptions): Signal<boolean>;

declare const MQ_BREAKPOINTS: InjectionToken<MqBreakpoints>;
declare const MQ_BREAKPOINT_EPSILON: InjectionToken<number>;

declare function provideBreakpoints(bps: MqBreakpoints): Provider;
declare function provideTailwindBreakpoints(): Provider;
declare function provideBootstrapBreakpoints(): Provider;
declare function provideMaterialBreakpoints(): Provider;
declare function provideBreakpointEpsilon(epsilon?: number): Provider;

export { MQ_BREAKPOINTS, MQ_BREAKPOINT_EPSILON, between, down, matchMediaSignal, provideBootstrapBreakpoints, provideBreakpointEpsilon, provideBreakpoints, provideMaterialBreakpoints, provideTailwindBreakpoints, release, retainUntilDestroy, up };
export type { CreateMediaQueryOptions, MqBreakpoints };
