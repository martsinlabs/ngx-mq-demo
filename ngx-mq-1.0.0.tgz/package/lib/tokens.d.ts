import { InjectionToken } from '@angular/core';
import { MqBreakpoints } from './models';
export declare const MQ_BREAKPOINTS: InjectionToken<MqBreakpoints>;
export declare const MQ_BREAKPOINT_EPSILON: InjectionToken<number>;
