import { MqBreakpoints } from './models';
export declare const TAILWIND_BREAKPOINTS: MqBreakpoints;
export declare const BOOTSTRAP_BREAKPOINTS: MqBreakpoints;
export declare const MATERIAL_BREAKPOINTS: MqBreakpoints;
export declare const DEFAULT_BREAKPOINT_EPSILON: number;
