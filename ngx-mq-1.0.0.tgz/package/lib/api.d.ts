import { Signal } from '@angular/core';
export declare function up(bp: string): Signal<boolean>;
export declare function down(bp: string): Signal<boolean>;
export declare function between(minBp: string, maxBp: string): Signal<boolean>;
export declare function matchMediaSignal(query: string): Signal<boolean>;
