import { Provider } from '@angular/core';
import { MqBreakpoints } from './models';
export declare function provideBreakpoints(bps: MqBreakpoints): Provider;
export declare function provideTailwindBreakpoints(): Provider;
export declare function provideBootstrapBreakpoints(): Provider;
export declare function provideMaterialBreakpoints(): Provider;
export declare function provideBreakpointEpsilon(epsilon?: number): Provider;
