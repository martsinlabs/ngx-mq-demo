import { MqBreakpoints } from '../models';
export declare function resolveBreakpoint(bp: string): number;
export declare function normalizeBreakpoints(bps: MqBreakpoints): Readonly<MqBreakpoints>;
export declare function validateEpsilon(epsilon: number): void;
export declare function applyMaxEpsilon(value: number): number;
