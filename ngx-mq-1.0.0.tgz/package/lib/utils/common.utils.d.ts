export declare function normalizeQuery(value: string): string;
