import { MqRetainToken, MqRetainRef } from './mql-registry.models';
export declare function retain(query: string): MqRetainRef;
export declare function release(query: string, token: MqRetainToken): boolean;
