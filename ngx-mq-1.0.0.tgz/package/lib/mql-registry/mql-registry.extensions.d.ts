import { MqRetainRef } from './mql-registry.models';
export declare function retainUntilDestroy(query: string): MqRetainRef;
