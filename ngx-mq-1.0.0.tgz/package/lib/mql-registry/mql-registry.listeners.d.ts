export declare function addChangeListenerToMql(mql: MediaQueryList, onChange: (event?: MediaQueryListEvent) => void): void;
export declare function removeChangeListenerFromMql(mql: MediaQueryList, onChange: (event?: MediaQueryListEvent) => void): void;
