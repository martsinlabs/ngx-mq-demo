import { Signal } from '@angular/core';
export declare function createConsumer(query: string): Signal<boolean>;
export declare function createConsumerLabel(descriptor: string): string;
