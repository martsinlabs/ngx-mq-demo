import { signal, inject, DestroyRef, InjectionToken, isDevMode, assertInInjectionContext } from '@angular/core';
import { createComputed } from '@angular/core/primitives/signals';

function addChangeListenerToMql(mql, onChange) {
    if (typeof mql.addEventListener === 'function') {
        // Modern browsers
        mql.addEventListener('change', onChange);
    }
    else {
        // Legacy fallback (Safari < 14)
        mql.addListener(onChange);
    }
}
function removeChangeListenerFromMql(mql, onChange) {
    if (typeof mql.removeEventListener === 'function') {
        // Modern browsers
        mql.removeEventListener('change', onChange);
    }
    else {
        // Legacy fallback (Safari < 14)
        mql.removeListener(onChange);
    }
}

const REGISTRY_KEY = Symbol.for('ngx-mq:mql-registry');
const getRegistry = () => {
    const realmGlobal = globalThis;
    return (realmGlobal[REGISTRY_KEY] ??= new Map());
};
const createRetainToken = (query) => Symbol(`mq-retainer:${query}`);
const createMqHandle = (query) => {
    const mql = matchMedia(query);
    const signal$1 = signal(mql.matches);
    const onChange = (event) => signal$1.set(event?.matches ?? mql.matches);
    addChangeListenerToMql(mql, onChange);
    return { mql, signal: signal$1, onChange, retainers: new Set() };
};
function retain(query) {
    const token = createRetainToken(query);
    // SSR-safe fallback
    if (typeof globalThis.matchMedia !== 'function') {
        return { signal: signal(false).asReadonly(), token };
    }
    const registry = getRegistry();
    let handle = registry.get(query);
    if (!handle) {
        handle = createMqHandle(query);
        registry.set(query, handle);
    }
    handle.retainers.add(token);
    return { signal: handle.signal.asReadonly(), token };
}
function release(query, token) {
    const registry = getRegistry();
    let handle = registry.get(query);
    if (!handle)
        return false;
    const removed = handle.retainers.delete(token);
    if (handle.retainers.size === 0) {
        removeChangeListenerFromMql(handle.mql, handle.onChange);
        registry.delete(query);
    }
    return removed;
}

function retainUntilDestroy(query) {
    const ref = retain(query);
    const destroyRef = inject(DestroyRef);
    destroyRef.onDestroy(() => release(query, ref.token));
    return ref;
}

const TAILWIND_BREAKPOINTS = {
    sm: 640,
    md: 768,
    lg: 1024,
    xl: 1280,
    '2xl': 1536,
};
const BOOTSTRAP_BREAKPOINTS = {
    sm: 576,
    md: 768,
    lg: 992,
    xl: 1200,
    xxl: 1400,
};
const MATERIAL_BREAKPOINTS = {
    sm: 600,
    md: 905,
    lg: 1240,
    xl: 1440,
};
const DEFAULT_BREAKPOINT_EPSILON = 0.02;

const MQ_BREAKPOINTS = new InjectionToken('MQ_BREAKPOINTS');
const MQ_BREAKPOINT_EPSILON = new InjectionToken('MQ_BREAKPOINT_EPSILON', {
    providedIn: 'root',
    factory: () => DEFAULT_BREAKPOINT_EPSILON,
});

function assertBreakpointsProvided() {
    const breakpoints = inject(MQ_BREAKPOINTS, { optional: true });
    if (isDevMode() && !breakpoints) {
        throw new Error('[ngx-mq]: No breakpoints provided.\n' +
            'Please configure your app with provideBreakpoints(), ' +
            'or use one of the built-in presets: ' +
            'provideTailwindBreakpoints(), provideBootstrapBreakpoints(), provideMaterialBreakpoints().');
    }
    return breakpoints;
}
function assertBreakpointExists(bp, breakpoints) {
    if (isDevMode() && !(bp in breakpoints)) {
        throw new Error(`[ngx-mq]: Breakpoint "${bp}" not found in provided configuration.\n` +
            `Available breakpoints: ${Object.keys(breakpoints).join(', ')}.`);
    }
    return breakpoints[bp];
}
function resolveBreakpoint(bp) {
    const breakpoints = assertBreakpointsProvided();
    return assertBreakpointExists(bp, breakpoints);
}
function normalizeBreakpoints(bps) {
    const out = {};
    for (const [rawKey, value] of Object.entries(bps)) {
        const key = rawKey.trim();
        if (isDevMode()) {
            if (!Number.isFinite(value)) {
                throw new Error(`[ngx-mq] Breakpoint "${key}" must be a finite number, got ${value}.`);
            }
            if (value <= 0) {
                throw new Error(`[ngx-mq] Breakpoint "${key}" must be > 0, got ${value}.`);
            }
        }
        out[key] = value;
    }
    return Object.freeze(out);
}
function validateEpsilon(epsilon) {
    if (!Number.isFinite(epsilon) || epsilon <= 0 || epsilon > 1) {
        throw new Error(`[ngx-mq] Epsilon must be in (0, 1]. Got: ${epsilon}`);
    }
}
function applyMaxEpsilon(value) {
    const epsilon = inject(MQ_BREAKPOINT_EPSILON, { optional: true }) ?? 0.02;
    return value - epsilon;
}

function createConsumer(query) {
    const retainRef = retainUntilDestroy(query);
    return createComputed(() => retainRef.signal());
}
function createConsumerLabel(descriptor) {
    return `[NgxMq Signal: ${descriptor}]`;
}

function normalizeQuery(value) {
    return value.trim().replace(/\s+/g, ' ').toLowerCase();
}

function up(bp) {
    isDevMode() && assertInInjectionContext(up);
    const query = normalizeQuery(`(min-width: ${resolveBreakpoint(bp)}px)`);
    const consumer = createConsumer(query);
    consumer.toString = () => createConsumerLabel(`up(${bp})`);
    return consumer;
}
function down(bp) {
    isDevMode() && assertInInjectionContext(down);
    const query = normalizeQuery(`(max-width: ${applyMaxEpsilon(resolveBreakpoint(bp))}px)`);
    const consumer = createConsumer(query);
    consumer.toString = () => createConsumerLabel(`down(${bp})`);
    return consumer;
}
function between(minBp, maxBp) {
    isDevMode() && assertInInjectionContext(between);
    const minPx = resolveBreakpoint(minBp);
    const maxPx = resolveBreakpoint(maxBp);
    const query = normalizeQuery(`(min-width: ${minPx}px) and (max-width: ${applyMaxEpsilon(maxPx)}px)`);
    const consumer = createConsumer(query);
    consumer.toString = () => createConsumerLabel(`between(${minBp}, ${maxBp})`);
    return consumer;
}
function matchMediaSignal(query) {
    isDevMode() && assertInInjectionContext(matchMediaSignal);
    const media = normalizeQuery(query);
    const consumer = createConsumer(media);
    consumer.toString = () => createConsumerLabel(`matchMediaSignal(${query})`);
    return consumer;
}

function provideBreakpoints(bps) {
    return { provide: MQ_BREAKPOINTS, useValue: normalizeBreakpoints(bps) };
}
function provideTailwindBreakpoints() {
    return provideBreakpoints(TAILWIND_BREAKPOINTS);
}
function provideBootstrapBreakpoints() {
    return provideBreakpoints(BOOTSTRAP_BREAKPOINTS);
}
function provideMaterialBreakpoints() {
    return provideBreakpoints(MATERIAL_BREAKPOINTS);
}
function provideBreakpointEpsilon(epsilon = DEFAULT_BREAKPOINT_EPSILON) {
    if (isDevMode())
        validateEpsilon(epsilon);
    return { provide: MQ_BREAKPOINT_EPSILON, useValue: epsilon };
}

/**
 * Generated bundle index. Do not edit.
 */

export { MQ_BREAKPOINTS, MQ_BREAKPOINT_EPSILON, between, down, matchMediaSignal, provideBootstrapBreakpoints, provideBreakpointEpsilon, provideBreakpoints, provideMaterialBreakpoints, provideTailwindBreakpoints, release, retainUntilDestroy, up };
//# sourceMappingURL=ngx-mq.mjs.map
